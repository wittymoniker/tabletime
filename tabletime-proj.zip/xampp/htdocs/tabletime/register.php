
<!DOCTYPE html>
<html>
	<head>
		<link href="style.css" rel="stylesheet" type="text/css">
<a href = "login.php"><h2>Login</h2></a>
		<title>tabletime</title>
	</head>
			


<body>

    <table style="background-color:#EFEFEF;" align = 
"center"><th>
		<div class="tabletime">
<?php include 'newuser.php'; ?>

			<h1>Register</h1>

    <div class="tabletime">
        <form method="post"action="newuser.php" autocomplete="off">
				<label for="username">
				
				</label>
				<input type="text" name="username" placeholder="name" id="username" required>
				<label for="password">
				
				</label>
				<input type="password" name="password" placeholder="code" id="password" required>
				<label for="email">
									</label>
				<input type="email" name="email" placeholder="msg" id="email" required>
				
            <div class="col-12">
                <div class="row">
                    <div class="col-md-6">
                        <div class="row">
                            <label for="quiz" 
                                   class="col-sm-3 col-form-label">
                                <?php echo $num1 . '+' . $num2; ?>
                            </label>
                            <div class="tabletime">
                                <input type="hidden" 
                                       name="no1" 
                                       value="<?php echo $num1 ?>">
                                <input type="hidden"
                                       name="no2" 
                                       value="<?php echo $num2 ?>">
                                <input type="text" 
                                       name="test"
                                       class="form-control quiz-control" 
                                       autocomplete="off"
                                       id="test" required>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <input type="submit" name= "submit" id = "submit" value="Register">
        </form>

		</div>
</th></table>
	</body>

       
    </div>
</body>




 


</html>


