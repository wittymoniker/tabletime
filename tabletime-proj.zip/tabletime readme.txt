Welcome to TableTime, a social network featuring:

-events
-tags
-tag-based object/location/event/post/group/status/ relevancy and conditional scoring system
-user status tags, group status tags, tag-based content management
-user tags with ratings and statistics
-groups
-posts/media
-global forum
-light scripting of posts for interactable menus and public
counters and embed containers
-text/video chat
-paid, taxed user-to-user ads
-advanced user-end-user analytics
-statistically derived global forum topics and content delivery (based on tags and content-based tags).




TO HOST AND/OR EDIT TABLETIME:
-full install XAMPP sever with MySQL and PhpMyAdmin via Apache. Directory to store tabletime scripts and files is detailed by the empty guide directory here, namely xampp\htdocs\tabletime.