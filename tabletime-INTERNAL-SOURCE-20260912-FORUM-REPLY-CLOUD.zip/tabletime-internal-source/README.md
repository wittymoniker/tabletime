# Tabletime internal source bundle — 2026-09-12

This archive intentionally contains both the complete current Tabletime application source and the server-host source codes for Tier-1 Host and Tier-2 Admin/Coordinator deployments.

The social-control restoration follows the original Tabletime README and historical source: Karma/Moksha `-256..+256`, scope `-256..+256` using `view/256`, the documented base delays, failed-attempt doubling, and `action_delay * number_of_votes / voteban_score` with an infinite edge.
