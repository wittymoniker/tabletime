# Tabletime server-host source

This source bundle contains both deployable node roles from the same refreshed Tabletime codebase:

- `host-tier1/` — independent host node (`config/node_tier.php` returns `host`).
- `admin-tier2/` — coordinator/admin node (`config/node_tier.php` returns `admin`).

Both include the restored Karma/Moksha and scoping sliders, README timing formula, persistent sessions, federation, WebRTC private/group/event calls and browser notifications. Configure MySQL, deploy the selected tree as the PHP document root, and visit `setup.php` once.
