<?php 
header("/tabletime/index.html");?>