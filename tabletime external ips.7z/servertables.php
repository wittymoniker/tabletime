<?php ;?>


<html class = "tabletime">
<link href="style.php" rel="stylesheet" type="text/css">
<head class = "html">
		<meta charset="utf-8">
		<title>TABLETIME</title>


<body class = "content">  

<form action = "colorpick.php">
<input type="color" name="style1a">
<input type="color" name="style2a">
<input type="color" name="style3a">
<input type="color" name="style4a">
<input type="color" name="style5a">
<input type="color" name="style6a"><br>

<input type="color" name="style1b">
<input type="color" name="style2b">
<input type="color" name="style3b">
<input type="color" name="style4b">
<input type="color" name="style5b">
<input type="color" name="style6b"><br>

<input type="color" name="style1c">
<input type="color" name="style2c">
<input type="color" name="style3c">
<input type="color" name="style4c">
<input type="color" name="style5c">
<input type="color" name="style6c"><br>
</form>
<p>
<h1>test:</h1>
<iframe src="home.php" title="TEST VIEW"></iframe>
</p>
</body>
</head>
</html>
