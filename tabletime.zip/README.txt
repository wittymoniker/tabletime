Welcome to TableTime, a social network featuring:

-events
-tags
-tag-based object/location/event/post/group/status/ relevancy and conditional scoring system
-user status tags, group status tags, tag-based content management
-user tags with ratings and statistics
-groups
-posts/media
-global forum
-light scripting of posts for interactable menus and public
counters and embed containers
-text/video chat
-paid, taxed user-to-user ads
-advanced user-end-user analytics
-statistically derived global forum topics and content delivery (based on tags and content-based tags).

How It Works - SAVE THIS TEXT

tabletime, while a shockingly detailed social algorithm,
obtains its beauty from rather simple effects. the majority
of the work is done through tags.
tags can be modified in their index values by unique
numeric parameters. You can look up and see all useful
calculated stats and how by searching anything you want. Tags
are considered, modified and delimited where a regular tag
value is 1, but with the exception that it is considered a
measureless topic tag, automatically factored as 1-to-1 in a
separate group from other tags. For example, if you posted a
picture of food that got done before the clams and soup with
appetizers, and wanted people to find your post only if they
were likely to want to show up on time and have a
predictable history of doing so;

...you make a post that says:
'at 5:00 I'm going to table. Make sure you're not late for
dinner but please don't worry either way. I made food. Respect
my table and cooking skills. Don't be late or early. Also
just me: Do you really think forks matter? If so, eat off my
porch because I'm not having dinner with you.'

If the tags are:
'food=0.5; table; fork <=7500; late=-15000 - 7500; food; -
late; -early;time; time = +15000 - 7500; 5:00 + 7500; dinner =
2; -angry; '.

...The first thing to know about your post and where it
will be and how it will help you find friends, is tags go
into two groups which are weighted one-to-one in searches
and content streams: numeric and (versus) non numeric.
The tags in this post imply that this post is about
someone who will make dinner at 5:00 at the table, that it will
be food and while that's essential and mutually inclusive to
the fact that it's on the table... because they also typed
'food=0.5' it would remove three quarters the value of any
number tags valued 2, and half that of 1, and one sixth that
of a tag the value of 3.

In the list of tags, tags and their values can be
negative. If the value is negative the post is repelled and will
be less visible from content with the tag itself. The tag '-
angry;' implies that your content will be one tag less
similar to a post with 'angry;' as a tag and also a step less
visible unless '-angry;' is also included. In the list of
tags it is more likely to be associated with the other
content or users if they have a low or negative value to the
tag. This math applies the tag will consider the negativity
of '-late;', 'early-;' and '-angry;', so that if 'angry;'
plus 'late;' or 'early;' with or without '-early;' and '-
late;' exists on another user or post, unless tags or
content '+food;' and 'table+;' plus at least 1/3 of the numeric
tags' total value is is present, there is no net attraction
to the content in posts or searches (or even negative). Just
remember that if they are outnumbered, the sum of tags of
either numeric or non-numeric quality side of this one-to-
one will scale (after - tags are compared with + tags in
numberless, regardless of how many others to at most 50% of the
proportionate tag value, if including even just one tag in
its group. The post also implies 'fork' contributes a tag
value equal to being late, unless people care about them
more than the contribution of the value 7500 to the rest of
the post in general.

External users get to rate a post and that effects its
tags. Dependant variables on the outsideof a global, group
or user post can be assigned to any tag plus the general
quality about the post. Votes on the quality of a post,
(given as a solid continuous good/bad slider tool) transfer in
proportion to each each tag value. The user has the ultimate
control to set the slider on their own post to vote the given
value of their post and tags to a one-to-one vote
against all other users. Because the user votes for the score of
thequality of a post, and it is their own to decide whether
they feel the such as in the example '+time = 15000 -
7500; 5:00 = 0 - 7500; dinner=-7500 -7500;late=-7500 +7500;'
it would mean that being late will be even more positive than
negative to content with '-late,' neutral with 'late;',
and negative against '+late;' by a score of 7500. On the slider,
'good' will go in the direction of the arithmetic +/- sign
and 'bad will go in the reverse direction.
Join today and get involved in the fun!








Rules, plus How We Decide About You

End users keep some small limited IP tables of is online
and split and help coordinate verification between Host and
Admin servers. They authenticate and are voted on their
reliability over time via other Dedicated Hosts as well as
resitricted by the ability of Admin Servers to dissimilate
conflict data manually or by polling the users merging the
servers.
Tabletime uses 1minute delays in forming messages, 3 minute
delays for group chats and video calls, 30 minute delays for
registration, 5 minute delays for posts, and 10 minute
delays for login attempts. Just has to be that way. we provide
the timestamps for dm, post, etc and lock the buttons but if
any successful events (including dms) happen what we'll do
is make it so people can vote ban them for extended periods
of time . if they have too many attempts failed for login
or register or post or anything, we double the delay for
that ip. if they have too many votebans or their posts get a
negative rating, use a delay factor that moves to infinite
time where they cant access the database and so either
delete the posts, messages, account etc to get the timer back
down.
To calculate delay a user has for accessing the database,
their overall voteban score is in balance with their delay
lock score. the delay is given by ((time of action delay) *
(number of votes) / their voteban score.) they must delete
their content, wait, or they cannot post or register on this
ip. finally, votebans are practically permanent, deletes an
importable account, and only one account export is permitted
when someone does get banned - these expire at high priority
as our servers prefer the freshest, most popular and most
active accounts data only. it will send emails of data when
it is deleted and accounts.
We have software for admin
and Dedicated Host as well as user peer hosting software.
They are deployable server programs which merge with
eachother in a network to expediate requests.
Admin servers manually merge with other admin servers and
use a IP organization scheme to host the IP under any single
domain server and link to each other. They are recommended
for 1/3 of data servers.
2/3 of data servers are Host servers which sit on IP
tables and do the same thing based on connected member webs,
they can be trusted to handle much data that is older than
the newest data.


TO HOST AND/OR EDIT TABLETIME:
-full install XAMPP sever with MySQL and PhpMyAdmin via Apache. Directory to store tabletime scripts and files is detailed by the empty guide directory here, namely xampp\htdocs\tabletime.