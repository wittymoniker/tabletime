# Tabletime GitHub release — natural ad credits

2026-09-14

This release uses the natural ad-credit exchange only. 1 ad credit = 1 counted impression. Paid ad-credit purchase/Stripe ad-credit routes are disabled. Existing private/public/global targeting, post subtypes, host features, Karma/Moksha, session timing, calls, notifications, federation, and maintenance hardening are retained.

## 2026-09-14 comment-only reply update
Removed all Reply as * controls. Comment now handles replies; Messages has explicit New message composition only.

2026-09-14 USER HOME STATS / MOKSHA EDIT PATCH
- Home now shows post count, post impressions/hits, top post by hits, top Moksha, top external Karma, and overall Karma/Moksha.
- Home includes editable Moksha creator-perspective sliders for the user's recent posts.
- Added privacy-aware, 10-minute-deduplicated general post impression tracking.
- Existing databases need one protected schema maintenance run before hit tracking begins.
