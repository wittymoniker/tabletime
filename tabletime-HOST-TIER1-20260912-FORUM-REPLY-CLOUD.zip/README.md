# tabletime-host-tier1
Refreshed Eski Tabletime host-node kit with federation, persistent sessions, private/group/event WebRTC calls, browser notifications, restored Karma/Moksha + scoping sliders, and the documented timing formula. Attach MySQL, deploy `app/` as the PHP document root, then open setup.php once.
