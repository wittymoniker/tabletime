Tabletime Tier 1 Host — 2026-09-14

This package is synchronized to the HOME-STATS-MOKSHA-EDIT-HIT-COUNT-NATURAL-ADS release.
Node tier is preset to host (Tier 1).
Includes:
- home user statistics (post count, post impressions/hits, top post, top Moksha, top external Karma)
- creator Moksha value editing
- natural ads: 1 ad credit = 1 impression; no paid ad-credit checkout
- comments as post replies; Reply-as-message post option removed
- post impression tracking with 10-minute dedupe
- current federation, session, host, privacy, and hardening behavior from the synchronized release

Existing databases require the protected schema maintenance run once to create post_impressions before hit counting begins.
TT_NODE_TIER environment variable, if set, overrides config/node_tier.php.
